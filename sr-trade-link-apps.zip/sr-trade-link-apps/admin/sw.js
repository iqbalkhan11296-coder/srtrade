/* Service worker: keeps the app installable and loads the app shell quickly.
   Data calls (Supabase) are never cached. */
const CACHE='sr-admin-v1';
const SHELL=['./','./index.html','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png','./icons/favicon-32.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{
  const req=e.request,url=new URL(req.url);
  if(req.method!=='GET')return;
  // The page itself: always try the network first so updates arrive, fall back to the saved copy offline.
  if(req.mode==='navigate'){
    e.respondWith(fetch(req).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put('./index.html',copy));return r;}).catch(()=>caches.match('./index.html')));
    return;
  }
  // Own static files (icons, manifest): cache first.
  if(url.origin===self.location.origin){
    e.respondWith(caches.match(req).then(hit=>hit||fetch(req).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put(req,copy));return r;})));
    return;
  }
  // Supabase library from jsDelivr: keep a copy so the app can start without a connection.
  if(url.hostname==='cdn.jsdelivr.net'){
    e.respondWith(caches.match(req).then(hit=>{const net=fetch(req).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put(req,copy));return r;}).catch(()=>hit);return hit||net;}));
  }
  // Everything else (Supabase API, etc.) goes straight to the network.
});
